<script setup>
import { RouterView } from 'vue-router'
import NavbarVue from './components/Navbar.vue';
import "./style.css"
</script>

<template>
  <NavbarVue />

  <RouterView />
</template>

