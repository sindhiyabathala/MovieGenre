<script setup>
</script>

<template>
  <main>
    Ping Pong
  </main>
</template>
